STAYFINDER IMAGE PATH FIX

This update prevents broken-image icons when a listing's stored photo path points to a file that is no longer present. It uses assets/img/placeholder.svg as a fallback and preserves valid uploaded image paths. It also includes the uploads/properties directory for future uploads.

INSTALL
1. Back up C:\xampp\htdocs\renthome first.
2. Extract this ZIP and copy its contents into C:\xampp\htdocs\renthome, choosing Replace for files.
3. Refresh the site using Ctrl+F5.

IMPORTANT: This code fix cannot recreate original property photos that are physically missing. If the old project folder or backup contains uploads\properties, copy those actual image files into C:\xampp\htdocs\renthome\uploads\properties. The database records may still exist, but image files are separate from the database.
