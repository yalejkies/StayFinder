STAYFINDER IMAGE UPLOAD FIX

Install: back up C:\xampp\htdocs\renthome, extract this ZIP, and copy its contents into that folder, replacing the relevant files. Keep your existing database. Then refresh with Ctrl+F5.

What this fix does:
- Creates uploads/properties/ with an .htaccess guard against PHP execution.
- Keeps owner listing image uploads saved as files and records relative paths in property_images.
- Normalizes common old image paths and shows the placeholder only when a file really is missing.
- Adds Owner Dashboard > Manage Photos so owners can upload replacement photos for existing listings. Missing database references are cleaned up only when replacement uploads succeed; actual existing files are not deleted.

Important: this package cannot recreate old photos that were never saved or have been deleted. Existing listings with missing image files need the photos re-uploaded using Dashboard > Manage Photos. New listings should upload photos on the Create Listing form.

Make sure Apache and MySQL are running. If uploads fail, check that the folder C:\xampp\htdocs\renthome\uploads\properties exists and Windows allows Apache to write to it.
