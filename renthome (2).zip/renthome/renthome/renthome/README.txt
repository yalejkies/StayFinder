STAYFINDER — CLEAN PROJECT PACKAGE
==================================

This package contains the StayFinder PHP/MySQL source, assets, SQL schema/migrations, and upload folders. It is organized for easier navigation; application folders and paths are preserved.

FOLDER GUIDE
- admin/       Admin dashboard and moderation pages
- owner/       Owner dashboard and listing management
- includes/    Shared authentication, validation, CSRF, and helper code
- config/      Database and application configuration
- database/    Database schema and migration SQL files
- assets/      CSS, logos, and placeholder image
- uploads/     Destination folders for property images, permits, and payment proofs
- tasks/       Renewal automation task
- docs/history/ Older phase notes and build/test logs retained for reference

XAMPP SETUP
1. Back up your existing project and database before replacing anything.
2. Extract the renthome folder into C:\xampp\htdocs\ so the path is C:\xampp\htdocs\renthome\.
3. Start Apache and MySQL in XAMPP.
4. Open http://localhost/renthome/setup.php and follow the setup instructions.
5. After creating an administrator account and confirming the site works, delete or rename setup.php.
6. If MySQL root has a password, update config/database.php before setup.

IMPORTANT BACKUP NOTES
- This ZIP contains application code and database schema/migrations, NOT your current database records or registered accounts. Export renthome_db from phpMyAdmin to preserve names, email addresses, listings, inquiries, and other saved records.
- Uploaded photos, permit files, and payment proof files must exist in uploads/ and be backed up separately. The included folders do not recreate missing original photos.
- Keep the project folder and SQL database export together when transferring StayFinder to another computer.
- The project uses the local URL /renthome. If you rename the folder, update config/app.php accordingly.

See PORTABLE_SETUP_README.txt and IMAGE_UPLOAD_FIX_README.txt for additional setup and image-upload notes.
